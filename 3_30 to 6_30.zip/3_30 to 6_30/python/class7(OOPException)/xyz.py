def a():print("A")
def b():print("B")
