print("Hello World")
print("We are pakistani")
print("kjaslkdjflaj")
print("Pakistan zinda bad")
